## Install dependencies

```D:\jenkins_example>npm install http-server -g```

<br/>

## Run server

```D:\jenkins_example> http-server```